const questions = [
    { question: "What is 5 + 7?", choices: [10, 11, 12, 13], correct: 12 },
    { question: "What is 8 * 6?", choices: [42, 46, 48, 52], correct: 48 },
    { question: "What is 9 - 4?", choices: [3, 4, 5, 6], correct: 5 },
    // You can add more custom questions here if desired
];

// Automatically generate questions to reach a total of 650
for (let i = questions.length; i < 650; i++) {
    const num1 = Math.floor(Math.random() * 100);
    const num2 = Math.floor(Math.random() * 100);
    const operation = Math.random() > 0.5 ? "+" : "*";
    const questionText = `What is ${num1} ${operation} ${num2}?`;
    const correctAnswer = operation === "+" ? num1 + num2 : num1 * num2;
    const choices = [
        correctAnswer,
        correctAnswer + Math.floor(Math.random() * 10) + 1,
        correctAnswer - Math.floor(Math.random() * 10) - 1,
        correctAnswer + Math.floor(Math.random() * 20) + 5
    ];
    questions.push({
        question: questionText,
        choices: shuffle(choices),
        correct: correctAnswer
    });
}

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

let currentQuestionIndex = 0;

function loadQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    document.getElementById('question-container').innerText = currentQuestion.question;

    const choicesContainer = document.getElementById('choices-container');
    choicesContainer.innerHTML = '';
    currentQuestion.choices.forEach(choice => {
        const button = document.createElement('button');
        button.innerText = choice;
        button.onclick = () => checkAnswer(choice);
        choicesContainer.appendChild(button);
    });

    document.getElementById('next-btn').style.display = 'none';
}

function checkAnswer(selectedChoice) {
    const currentQuestion = questions[currentQuestionIndex];
    if (selectedChoice === currentQuestion.correct) {
        alert('Correct!');
        document.getElementById('next-btn').style.display = 'inline-block';
    } else {
        alert('Wrong answer, try again.');
    }
}

document.getElementById('next-btn').onclick = () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        alert('Congratulations! You have completed all the questions.');
        document.getElementById('game-container').innerHTML = '<h2>You completed the game!</h2>';
    }
};

loadQuestion();
